#pragma once

#include "common.h"

void recoverData(vBytes& png_vec);
