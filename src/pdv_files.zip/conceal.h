#pragma once

#include "common.h"

void concealData(vBytes& png_vec, Option option, const fs::path& data_file_path);
